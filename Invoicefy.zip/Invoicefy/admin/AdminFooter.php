<style type="text/css">
	.text-muted{
		font-size: larger;
	}
</style>
	<footer class="footer mt-auto border-top py-3 bg-white">
	  <div class="text-center container">
	    <span class="text-muted">Made with&nbsp;<span style="font-size: 1rem"><i class="fas fa-heart"></i></span>&nbsp;&&nbsp;<span style="font-size: 1rem"><i class="fas fa-coffee"></i></span>&nbsp;by Nikhil & Burhan.</span><br>
	    <span class="text-center text-muted"><span style="font-size: 1rem"><i class="fas fa-copyright"></i></span>&nbsp;invoicefy 2019-20</span>
	  </div>
	</footer>
</body>
</html>