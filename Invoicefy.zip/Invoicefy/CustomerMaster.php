<?php 
  include('inclds/head.php');
  include('inclds/head2.php');
?>
<div id="main" class="container bg-light rounded bg-white shadow-sm">	
	<form class="form-group p-3 needs-validation" method="POST" name="Supplier">
		<h4 class="text-primary">Customer Master</h4>
    <hr class="mb-4">
    <div>
      <a href="AddCustomer.php" class="btn btn-light">Create New</a>&nbsp&nbsp&nbsp
      <a href="UpdateCustomer.php" class="btn btn-light">Update Existing</a>
    </div><br>
  </form>
</div>
