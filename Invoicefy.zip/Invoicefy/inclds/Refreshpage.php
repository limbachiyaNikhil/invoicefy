<script>
    function pageRedirect() {
        window.location = window.location.href;
    }      
    setTimeout("pageRedirect()", 1);
</script>