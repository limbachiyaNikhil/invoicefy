<script>
    function pageRedirect() {
        window.location.replace("login.php");
    }      
    setTimeout("pageRedirect()", 1);
</script>